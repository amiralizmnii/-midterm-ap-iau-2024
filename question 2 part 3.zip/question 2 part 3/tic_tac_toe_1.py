
def createBoard():
    board = [
        [" "," ", " "],
        [" "," ", " "],
        [" "," ", " "],
    ]
    return board